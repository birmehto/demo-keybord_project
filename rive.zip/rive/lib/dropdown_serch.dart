import 'package:flutter/material.dart';
import 'package:searchfield/searchfield.dart';

import 'const.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dropdown Test App',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: DropdownTestScreen(),
    );
  }
}

class DropdownTestScreen extends StatefulWidget {
  @override
  _DropdownTestScreenState createState() => _DropdownTestScreenState();
}

class _DropdownTestScreenState extends State<DropdownTestScreen> {
  final _searchFieldController = TextEditingController();
  final _searchFieldFocus = FocusNode();

  String? _selectedItem;

  @override
  void dispose() {
    _searchFieldController.dispose();
    _searchFieldFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dropdown Package Comparison'),
        backgroundColor: Colors.blue.shade100,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 32),

            Text(
              '2. searchfield',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),

            SearchField<String>(
              controller: _searchFieldController,
              focusNode: _searchFieldFocus,
              suggestions: allItems.map((name) {
                return SearchFieldListItem<String>(
                  name,
                  item: name,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Text(name, style: TextStyle(fontSize: 16)),
                  ),
                );
              }).toList(),
              onSuggestionTap: (suggestion) {
                setState(() {
                  _selectedItem = suggestion.item;
                });
              },
              searchInputDecoration: SearchInputDecoration(
                labelText: 'Select Item',
                hintText: 'Type to search...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
              maxSuggestionsInViewPort: 5,
            ),

            if (_selectedItem != null)
              Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  'Selected: $_selectedItem',
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

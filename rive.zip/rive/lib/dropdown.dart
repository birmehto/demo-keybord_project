import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

class CommonSearchableDropdown<T> extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final String? labelText;
  final String? hintText;
  final Future<List<T>> Function(String) suggestionsCallback;
  final Widget Function(BuildContext, T) itemBuilder;
  final void Function(T) onSelected;

  const CommonSearchableDropdown({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.suggestionsCallback,
    required this.itemBuilder,
    required this.onSelected,
    this.labelText,
    this.hintText,
  });

  @override
  State<CommonSearchableDropdown<T>> createState() =>
      _CommonSearchableDropdownState<T>();
}

class _CommonSearchableDropdownState<T>
    extends State<CommonSearchableDropdown<T>> {
  int _highlightedIndex = -1;
  List<T> _suggestions = [];
  bool _isDropdownOpen = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(_onFocusChange);
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocusChange);
    super.dispose();
  }

  void _onFocusChange() {
    if (!widget.focusNode.hasFocus) {
      setState(() {
        _isDropdownOpen = false;
        _highlightedIndex = -1;
      });
    }
  }

  void _moveHighlight(int direction) {
    if (_suggestions.isEmpty || !_isDropdownOpen) return;

    setState(() {
      if (_highlightedIndex == -1) {
        _highlightedIndex = direction == 1 ? 0 : _suggestions.length - 1;
      } else {
        int newIndex = _highlightedIndex + direction;

        // Wrap around behavior like websites
        if (newIndex < 0) {
          _highlightedIndex = _suggestions.length - 1;
        } else if (newIndex >= _suggestions.length) {
          _highlightedIndex = 0;
        } else {
          _highlightedIndex = newIndex;
        }
      }
    });
  }

  void _selectHighlighted() {
    if (_highlightedIndex >= 0 &&
        _highlightedIndex < _suggestions.length &&
        _isDropdownOpen) {
      widget.onSelected(_suggestions[_highlightedIndex]);
      setState(() {
        _highlightedIndex = -1;
        _isDropdownOpen = false;
      });
    }
  }

  KeyEventResult _handleKeyPress(FocusNode node, KeyEvent event) {
    if (event is KeyDownEvent && _isDropdownOpen) {
      switch (event.logicalKey) {
        case LogicalKeyboardKey.arrowDown:
          _moveHighlight(1);
          return KeyEventResult.handled;
        case LogicalKeyboardKey.arrowUp:
          _moveHighlight(-1);
          return KeyEventResult.handled;
        case LogicalKeyboardKey.enter:
          _selectHighlighted();
          return KeyEventResult.handled;
        case LogicalKeyboardKey.escape:
          setState(() {
            _isDropdownOpen = false;
            _highlightedIndex = -1;
          });
          return KeyEventResult.handled;
      }
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      onKeyEvent: _handleKeyPress,
      child: TypeAheadField<T>(
        controller: widget.controller,
        focusNode: widget.focusNode,
        suggestionsCallback: (pattern) async {
          final results = await widget.suggestionsCallback(pattern);
          setState(() {
            _suggestions = results;
            _isDropdownOpen = results.isNotEmpty;
            _highlightedIndex = -1; // Reset highlight
          });
          return results;
        },
        itemBuilder: (context, suggestion) {
          final index = _suggestions.indexOf(suggestion);
          final isHighlighted = index == _highlightedIndex;
          return Container(
            color: isHighlighted ? Colors.blue.withValues(alpha: 0.2) : null,
            child: widget.itemBuilder(context, suggestion),
          );
        },
        onSelected: (suggestion) {
          widget.onSelected(suggestion);
          setState(() {
            _highlightedIndex = -1;
            _isDropdownOpen = false;
          });
        },
        builder: (context, textEditingController, focusNode) {
          return TextField(
            controller: textEditingController,
            focusNode: focusNode,
            decoration: InputDecoration(
              labelText: widget.labelText,
              hintText: widget.hintText,
            ),
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:rive/const.dart';

import 'search_dropdown.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Custom Dropdown Demo',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final seachController = TextEditingController();
    final focusNode = FocusNode();
    return Scaffold(
      appBar: AppBar(title: const Text('Reusable Dropdown')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SearchDropdown(
              label: "Fruits",
              controller: seachController,
              focusNode: focusNode,
              items: allItems,
              onChanged: (value) {
                print("Selected: $value");
              },
            ),
            const SizedBox(height: 20),
            SearchDropdown(
              label: "Vegetables",
              controller: TextEditingController(),
              focusNode: FocusNode(),
              items: const [
                'Carrot',
                'Broccoli',
                'Spinach',
                'Potato',
                'Tomato',
                'Onion',
                'Garlic',
                'Bell Pepper',
                'Cucumber',
                'Lettuce',
              ],
              onChanged: (value) {
                print("Selected: $value");
              },
            ),
            const SizedBox(height: 20),
            SearchDropdown(
              label: "Colors",
              controller: TextEditingController(),
              focusNode: FocusNode(),
              items: const [
                'Red',
                'Blue',
                'Green',
                'Yellow',
                'Purple',
                'Orange',
                'Black',
                'White',
                'Pink',
                'Brown',
              ],
              onChanged: (value) {
                print("Selected: $value");
              },
            ),
          ],
        ),
      ),
      // body: CustomFormNavigationExample(),
    );
  }
}

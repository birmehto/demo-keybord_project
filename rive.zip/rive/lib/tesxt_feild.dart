import 'package:flutter/material.dart';

class CustomFormNavigationExample extends StatefulWidget {
  @override
  State<CustomFormNavigationExample> createState() =>
      _CustomFormNavigationExampleState();
}

class _CustomFormNavigationExampleState
    extends State<CustomFormNavigationExample> {
  final focusNode1 = FocusNode();
  final focusNode2 = FocusNode();
  final focusNode3 = FocusNode();
  final focusNode4 = FocusNode();

  @override
  void dispose() {
    focusNode1.dispose();
    focusNode2.dispose();
    focusNode3.dispose();
    focusNode4.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: FocusTraversalGroup(
          // Optional but recommended
          child: Column(
            children: [
              TextFormField(
                focusNode: focusNode1,
                decoration: InputDecoration(labelText: 'Field 1'),
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) {
                  FocusScope.of(context).requestFocus(focusNode2);
                },
              ),
              TextFormField(
                focusNode: focusNode2,
                decoration: InputDecoration(labelText: 'Field 2'),
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) {
                  FocusScope.of(context).requestFocus(focusNode3);
                },
              ),
              TextFormField(
                focusNode: focusNode3,
                decoration: InputDecoration(labelText: 'Ship Field'),
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) {
                  FocusScope.of(context).requestFocus(focusNode4);
                },
              ),
              TextFormField(
                focusNode: focusNode4,
                decoration: InputDecoration(labelText: 'Field 4'),
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) {
                  FocusScope.of(context).unfocus();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

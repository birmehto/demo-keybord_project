import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

class InAppPurchaseExample extends StatefulWidget {
  @override
  _InAppPurchaseExampleState createState() => _InAppPurchaseExampleState();
}

class _InAppPurchaseExampleState extends State<InAppPurchaseExample> {
  final InAppPurchase _iap = InAppPurchase.instance;
  bool _available = false;
  List<ProductDetails> _products = [];
  List<PurchaseDetails> _purchases = [];

  final Set<String> _kProductIds = {'your_product_id_1', 'your_product_id_2'};

  @override
  void initState() {
    super.initState();
    _initStore();
  }

  void _initStore() async {
    _available = await _iap.isAvailable();

    if (_available) {
      final ProductDetailsResponse response = await _iap.queryProductDetails(_kProductIds);
      setState(() {
        _products = response.productDetails;
      });

      // Listen to purchase updates
      _iap.purchaseStream.listen((purchaseDetailsList) {
        _listenToPurchaseUpdated(purchaseDetailsList);
      });
    }
  }

  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    for (var purchaseDetails in purchaseDetailsList) {
      if (purchaseDetails.status == PurchaseStatus.purchased) {
        // Verify purchase, deliver product, etc.
        // IMPORTANT: verify purchase on server for real apps
        _purchases.add(purchaseDetails);
        _completePurchase(purchaseDetails);
      }
      else if (purchaseDetails.status == PurchaseStatus.error) {
        // Handle error
        print('Purchase error: ${purchaseDetails.error}');
      }
      else if (purchaseDetails.status == PurchaseStatus.restored) {
        // Restore purchases
        _purchases.add(purchaseDetails);
      }
    }
    setState(() {});
  }

  void _completePurchase(PurchaseDetails purchaseDetails) {
    if (purchaseDetails.pendingCompletePurchase) {
      _iap.completePurchase(purchaseDetails);
    }
  }

  void _buyProduct(ProductDetails productDetails) {
    final purchaseParam = PurchaseParam(productDetails: productDetails);
    _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  @override
  Widget build(BuildContext context) {
    if (!_available) {
      return Center(child: Text('In-app purchases not available'));
    }

    return ListView(
      children: _products.map((product) {
        return ListTile(
          title: Text(product.title),
          subtitle: Text(product.description),
          trailing: TextButton(
            child: Text(product.price),
            onPressed: () => _buyProduct(product),
          ),
        );
      }).toList(),
    );
  }
}
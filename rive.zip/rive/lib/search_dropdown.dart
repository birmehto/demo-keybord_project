import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:searchfield/searchfield.dart';

class SearchDropdown extends StatelessWidget {
  final List<String> items;
  final String label;
  final String? initialValue;
  final TextEditingController controller;
  final FocusNode focusNode;

  final String? labelText;
  final String? hintText;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onTap;
  final VoidCallback? onClear;

  final int? maxLength;
  final bool isMandatory;
  final bool showSuffixIcons;
  final bool enabled;
  final TextCapitalization textCapitalization;
  final List<TextInputFormatter>? inputFormatters;
  final int maxSuggestions;
  final Duration debounceDuration;

  const SearchDropdown({
    super.key,
    required this.items,
    required this.label,
    required this.controller,
    required this.focusNode,
    this.initialValue,
    this.labelText,
    this.hintText,
    this.onChanged,
    this.onTap,
    this.onClear,
    this.maxLength,
    this.isMandatory = false,
    this.showSuffixIcons = true,
    this.enabled = true,
    this.textCapitalization = TextCapitalization.none,
    this.inputFormatters,
    this.maxSuggestions = 5,
    this.debounceDuration = const Duration(milliseconds: 300),
  });

  @override
  Widget build(BuildContext context) {
    return SearchField<String>(
      controller: controller..text = initialValue ?? '',
      focusNode: focusNode,
      suggestions: items
          .map(
            (item) => SearchFieldListItem<String>(
              item,
              item: item,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: Text(item, style: const TextStyle(fontSize: 16)),
              ),
            ),
          )
          .toList(),
      onSuggestionTap: (suggestion) {
        controller.text = suggestion.item ?? '';
        onChanged?.call(suggestion.item ?? '');
      },
      maxSuggestionsInViewPort: maxSuggestions,
      suggestionState: Suggestion.expand, // keeps dropdown open
      searchInputDecoration: SearchInputDecoration(
        labelText: isMandatory ? '${labelText ?? label} *' : labelText ?? label,
        hintText: hintText ?? 'Type to search...',
        border: const OutlineInputBorder(),
        prefixIcon: const Icon(Icons.search),
        suffixIcon: showSuffixIcons
            ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (controller.text.isNotEmpty)
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        controller.clear();
                        onClear?.call();
                      },
                    ),
                  const Icon(Icons.keyboard_arrow_down),
                ],
              )
            : null,
      ),
      inputFormatters: inputFormatters,
      enabled: enabled,
    );
  }
}

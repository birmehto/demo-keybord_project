// class CommonSearchableDropdown<T> extends StatefulWidget {
//   final TextEditingController controller;
//   final FocusNode focusNode;
//   final String? labelText;
//   final String? hintText;
//   final Future<List<T>> Function(String) suggestionsCallback;
//   final Widget Function(BuildContext, T) itemBuilder;
//   final void Function(T) onSelected;

//   const CommonSearchableDropdown({
//     super.key,
//     required this.controller,
//     required this.focusNode,
//     required this.suggestionsCallback,
//     required this.itemBuilder,
//     required this.onSelected,
//     this.labelText,
//     this.hintText,
//   });

//   @override
//   State<CommonSearchableDropdown<T>> createState() =>
//       _CommonSearchableDropdownState<T>();
// }

// class _CommonSearchableDropdownState<T>
//     extends State<CommonSearchableDropdown<T>> {
//   final FocusNode _keyboardFocusNode = FocusNode();
//   int _highlightedIndex = -1;
//   List<T> _suggestions = [];

//   @override
//   void dispose() {
//     _keyboardFocusNode.dispose();
//     super.dispose();
//   }

//   void _moveHighlight(int direction) {
//     if (_suggestions.isEmpty) return;
//     setState(() {
//       _highlightedIndex = (_highlightedIndex + direction).clamp(
//         0,
//         _suggestions.length - 1,
//       );
//     });
//   }

//   void _selectHighlighted() {
//     if (_highlightedIndex >= 0 && _highlightedIndex < _suggestions.length) {
//       widget.onSelected(_suggestions[_highlightedIndex]);
//       setState(() {
//         _highlightedIndex = -1;
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return RawKeyboardListener(
//       focusNode: _keyboardFocusNode,
//       onKey: (event) {
//         if (event is RawKeyDownEvent) {
//           if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
//             _moveHighlight(1);
//           } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
//             _moveHighlight(-1);
//           } else if (event.logicalKey == LogicalKeyboardKey.enter) {
//             _selectHighlighted();
//           }
//         }
//       },
//       child: TypeAheadField<T>(
//         controller: widget.controller,
//         focusNode: widget.focusNode,
//         suggestionsCallback: (pattern) async {
//           final results = await widget.suggestionsCallback(pattern);
//           setState(() {
//             _suggestions = results;
//             _highlightedIndex = results.isEmpty ? -1 : 0;
//           });
//           return results;
//         },
//         itemBuilder: (context, suggestion) {
//           final index = _suggestions.indexOf(suggestion);
//           final isHighlighted = index == _highlightedIndex;
//           return Container(
//             color: isHighlighted ? Colors.blue.withOpacity(0.2) : null,
//             child: widget.itemBuilder(context, suggestion),
//           );
//         },
//         onSelected: (suggestion) {
//           widget.onSelected(suggestion);
//           setState(() {
//             _highlightedIndex = -1;
//           });
//         },
//         builder: (context, textEditingController, focusNode) {
//           return TextField(
//             controller: textEditingController,
//             focusNode: focusNode,
//             decoration: InputDecoration(
//               labelText: widget.labelText,
//               hintText: widget.hintText,
//             ),
//             onTap: () {
//               // Give keyboard listener focus when textfield is tapped
//               _keyboardFocusNode.requestFocus();
//             },
//           );
//         },
//       ),
//     );
//   }
// }

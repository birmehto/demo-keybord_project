//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import in_app_purchase_storekit

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  InAppPurchasePlugin.register(with: registry.registrar(forPlugin: "InAppPurchasePlugin"))
}
